package service;

import model.*;
import java.util.*;

public class AuthenticationService {
    private List<User> systemUsers; // Admin, Manager from users.txt
    private List<Customer> customers;

    public AuthenticationService(List<User> systemUsers, List<Customer> customers){
        this.systemUsers=systemUsers;
        this.customers=customers;
    }

    public User login(String username, String password){
        for(User u: systemUsers){
            if(u.getUsername().equals(username) && u.getPassword().equals(password)){
                return u;
            }
        }
        for(Customer c: customers){
            if(c.getUsername().equals(username) && c.getPassword().equals(password)){
                return c;
            }
        }
        throw new IllegalArgumentException("Invalid username or password");
    }

    public Customer registerCustomer(String id, String fullName, String username, String password, String phone, String email, int age, String gender, String license){
        // check duplicate username
        for(Customer c: customers){
            if(c.getUsername().equalsIgnoreCase(username)) throw new IllegalArgumentException("Username already exists");
        }
        Customer newCust = new Customer(id, fullName, username, password, phone, email, age, gender, license);
        customers.add(newCust);
        return newCust;
    }
}
