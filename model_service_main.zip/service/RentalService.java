package service;

import model.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;

public class RentalService {
    private List<Vehicle> vehicles;
    private List<Customer> customers;
    private List<Rental> rentals;

    public RentalService(List<Vehicle> vehicles, List<Customer> customers, List<Rental> rentals){
        this.vehicles=vehicles;
        this.customers=customers;
        this.rentals=rentals;
    }

    public Vehicle findVehicleById(String id){
        return vehicles.stream().filter(v->v.getVehicleID().equalsIgnoreCase(id)).findFirst().orElse(null);
    }
    public Customer findCustomerById(String id){
        return customers.stream().filter(c->c.getID().equalsIgnoreCase(id)).findFirst().orElse(null);
    }
    public Rental findRentalById(String id){
        return rentals.stream().filter(r->r.getRentalID().equalsIgnoreCase(id)).findFirst().orElse(null);
    }

    // Validation Rules implementation
    public Rental createRental(String rentalId, String customerId, String vehicleId, LocalDate rentalDate, LocalDate returnDate){
        Customer cust = findCustomerById(customerId);
        if(cust==null) throw new IllegalArgumentException("Customer not found: "+customerId);
        if(cust.getLicenseNumber()==null || cust.getLicenseNumber().trim().isEmpty()){
            throw new IllegalArgumentException("Customer cannot rent without valid driver's license");
        }
        Vehicle veh = findVehicleById(vehicleId);
        if(veh==null) throw new IllegalArgumentException("Vehicle not found: "+vehicleId);
        if(!veh.isAvailable()){
            throw new IllegalStateException("Vehicle is not available or under maintenance: "+veh.getAvailabilityStatus());
        }
        if(rentalDate.isBefore(LocalDate.now())){
            throw new IllegalArgumentException("Rental date cannot be in the past");
        }
        if(!returnDate.isAfter(rentalDate)){
            throw new IllegalArgumentException("Return date must be after rental date");
        }

        long days = ChronoUnit.DAYS.between(rentalDate, returnDate);
        if(days==0) days=1;
        double total = days * veh.getRentalPricePerDay();

        Rental rental = new Rental(rentalId, customerId, vehicleId, rentalDate, returnDate, null, total, "Active");
        rentals.add(rental);
        veh.setAvailabilityStatus("Rented");
        System.out.println("Rental created successfully: "+rentalId+" Total: "+total);
        return rental;
    }

    public void returnVehicle(String rentalId, LocalDate actualReturn){
        Rental r = findRentalById(rentalId);
        if(r==null) throw new IllegalArgumentException("Rental not found");
        if("Cancelled".equalsIgnoreCase(r.getStatus())){
            throw new IllegalStateException("Cancelled rental cannot be marked as completed");
        }
        if("Completed".equalsIgnoreCase(r.getStatus())){
            throw new IllegalStateException("Rental already completed");
        }
        r.setActualReturnDate(actualReturn);
        Vehicle v = findVehicleById(r.getVehicleID());
        long days = ChronoUnit.DAYS.between(r.getRentalDate(), actualReturn);
        if(days<=0) days=1;
        double newTotal = days * (v!=null?v.getRentalPricePerDay():0);
        r.setTotalCost(newTotal);
        r.setStatus("Completed");
        if(v!=null) v.setAvailabilityStatus("Available");
        System.out.println("Vehicle returned. Rental completed.");
    }

    public void cancelRental(String rentalId){
        Rental r = findRentalById(rentalId);
        if(r==null) throw new IllegalArgumentException("Rental not found");
        if("Completed".equalsIgnoreCase(r.getStatus())){
            throw new IllegalStateException("Completed rental cannot be cancelled");
        }
        r.setStatus("Cancelled");
        Vehicle v = findVehicleById(r.getVehicleID());
        if(v!=null) v.setAvailabilityStatus("Available");
        System.out.println("Rental cancelled: "+rentalId);
    }

    public List<Vehicle> getAvailableVehicles(){
        List<Vehicle> list = new ArrayList<>();
        for(Vehicle v: vehicles) if(v.isAvailable()) list.add(v);
        return list;
    }

    public List<Rental> getRentalsByCustomer(String customerId){
        List<Rental> list = new ArrayList<>();
        for(Rental r: rentals) if(r.getCustomerID().equalsIgnoreCase(customerId)) list.add(r);
        return list;
    }

    public void addVehicle(Vehicle v){ vehicles.add(v); }
    public void registerCustomer(Customer c){ customers.add(c); }

    public List<Vehicle> getVehicles(){ return vehicles; }
    public List<Customer> getCustomers(){ return customers; }
    public List<Rental> getRentals(){ return rentals; }
}
