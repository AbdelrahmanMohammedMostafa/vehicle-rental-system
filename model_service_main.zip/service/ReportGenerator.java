package service;

import model.*;
import java.time.Month;
import java.util.*;
import java.util.stream.Collectors;

public class ReportGenerator {
    private List<Vehicle> vehicles;
    private List<Customer> customers;
    private List<Rental> rentals;

    public ReportGenerator(List<Vehicle> vehicles, List<Customer> customers, List<Rental> rentals){
        this.vehicles=vehicles;
        this.customers=customers;
        this.rentals=rentals;
    }

    public void systemOverviewReport(){
        System.out.println("\n=== System Overview Report ===");
        System.out.println("Total vehicles: "+vehicles.size());
        System.out.println("Total customers: "+customers.size());
        Map<String, Long> byStatus = rentals.stream().collect(Collectors.groupingBy(r->r.getStatus().toLowerCase(), Collectors.counting()));
        System.out.println("Total rentals: "+rentals.size());
        System.out.println("Rentals by status: "+byStatus);
    }

    public void vehicleUtilizationReport(){
        System.out.println("\n=== Vehicle Utilization Report ===");
        Map<String, Long> countMap = rentals.stream().collect(Collectors.groupingBy(Rental::getVehicleID, Collectors.counting()));
        List<Map.Entry<String, Long>> top = countMap.entrySet().stream().sorted((a,b)->Long.compare(b.getValue(), a.getValue())).limit(5).collect(Collectors.toList());
        System.out.println("Top 5 most rented vehicles:");
        for(Map.Entry<String, Long> e: top){
            Vehicle v = vehicles.stream().filter(ve->ve.getVehicleID().equals(e.getKey())).findFirst().orElse(null);
            System.out.println(" - "+e.getKey()+(v!=null?" ("+v.getModel()+")":"")+" : "+e.getValue()+" times");
        }
        long available = vehicles.stream().filter(Vehicle::isAvailable).count();
        long maintenance = vehicles.stream().filter(v->"Maintenance".equalsIgnoreCase(v.getAvailabilityStatus())).count();
        System.out.println("Available vehicles: "+available);
        System.out.println("Vehicles under maintenance: "+maintenance);
    }

    public void revenueReport(){
        System.out.println("\n=== Revenue Report ===");
        double total = rentals.stream().filter(r->!"Cancelled".equalsIgnoreCase(r.getStatus())).mapToDouble(Rental::getTotalCost).sum();
        System.out.printf("Total revenue: %.2f%n", total);

        Map<String, Double> byType = new HashMap<>();
        for(Rental r: rentals){
            if("Cancelled".equalsIgnoreCase(r.getStatus())) continue;
            Vehicle v = vehicles.stream().filter(ve->ve.getVehicleID().equals(r.getVehicleID())).findFirst().orElse(null);
            if(v!=null){
                String type = v.getType();
                byType.put(type, byType.getOrDefault(type,0.0)+r.getTotalCost());
            }
        }
        System.out.println("Revenue by vehicle type: "+byType);

        Map<Month, Double> monthly = new HashMap<>();
        for(Rental r: rentals){
            if(r.getRentalDate()!=null && !"Cancelled".equalsIgnoreCase(r.getStatus())){
                Month m = r.getRentalDate().getMonth();
                monthly.put(m, monthly.getOrDefault(m,0.0)+r.getTotalCost());
            }
        }
        System.out.println("Monthly revenue: "+monthly);
    }

    public void customerActivityReport(){
        System.out.println("\n=== Customer Activity Report ===");
        Map<String, Long> freq = rentals.stream().collect(Collectors.groupingBy(Rental::getCustomerID, Collectors.counting()));
        List<Map.Entry<String, Long>> top = freq.entrySet().stream().sorted((a,b)->Long.compare(b.getValue(), a.getValue())).limit(5).collect(Collectors.toList());
        System.out.println("Top 5 customers by rental frequency:");
        for(Map.Entry<String, Long> e: top){
            Customer c = customers.stream().filter(cu->cu.getID().equals(e.getKey())).findFirst().orElse(null);
            System.out.println(" - "+e.getKey()+(c!=null?" ("+c.getFullName()+")":"")+" : "+e.getValue());
        }
        System.out.println("\nCustomers with overdue rentals:");
        boolean found=false;
        for(Rental r: rentals){
            if("Active".equalsIgnoreCase(r.getStatus()) && r.getReturnDate()!=null && r.getReturnDate().isBefore(java.time.LocalDate.now())){
                System.out.println(" - "+r.getCustomerID()+" Rental "+r.getRentalID()+" overdue since "+r.getReturnDate());
                found=true;
            }
        }
        if(!found) System.out.println(" None");
    }

    public void generateAll(){
        systemOverviewReport();
        vehicleUtilizationReport();
        revenueReport();
        customerActivityReport();
    }
}
