import model.*;
import service.*;
import storage.FileManager;
import java.time.LocalDate;
import java.util.*;

public class Main {
    private static Scanner scanner = new Scanner(System.in);
    private static FileManager fileManager = new FileManager("resources");
    private static List<Vehicle> vehicles;
    private static List<Customer> customers;
    private static List<Rental> rentals;
    private static List<User> systemUsers;
    private static RentalService rentalService;
    private static AuthenticationService authService;
    private static ReportGenerator reportGenerator;

    public static void main(String[] args){
        System.out.println("=== Vehicle Rental Management System ===");
        loadData();

        rentalService = new RentalService(vehicles, customers, rentals);
        authService = new AuthenticationService(systemUsers, customers);
        reportGenerator = new ReportGenerator(vehicles, customers, rentals);

        while(true){
            System.out.println("\n--- Login Menu ---");
            System.out.println("1. Login");
            System.out.println("2. Register as Customer");
            System.out.println("3. Exit");
            System.out.print("Choice: ");
            String choice = scanner.nextLine();
            try{
                if("1".equals(choice)){
                    System.out.print("Username: "); String u = scanner.nextLine();
                    System.out.print("Password: "); String p = scanner.nextLine();
                    User logged = authService.login(u,p);
                    System.out.println("Welcome "+logged.getFullName()+" ("+logged.getClass().getSimpleName()+")");
                    if(logged instanceof Admin) adminMenu((Admin)logged);
                    else if(logged instanceof Manager) managerMenu((Manager)logged);
                    else if(logged instanceof Customer) customerMenu((Customer)logged);
                } else if("2".equals(choice)){
                    registerFlow();
                } else if("3".equals(choice)){
                    saveData();
                    System.out.println("Goodbye!");
                    break;
                }
            }catch(Exception ex){
                System.err.println("Error: "+ex.getMessage());
            }
        }
    }

    private static void loadData(){
        try{
            vehicles = fileManager.loadVehicles();
            customers = fileManager.loadCustomers();
            rentals = fileManager.loadRentals();
            systemUsers = fileManager.loadSystemUsers();
            System.out.printf("Loaded: %d vehicles, %d customers, %d rentals, %d system users%n",
                vehicles.size(), customers.size(), rentals.size(), systemUsers.size());
        }catch(Exception e){
            System.err.println("Failed to load: "+e.getMessage());
            vehicles = new ArrayList<>(); customers=new ArrayList<>(); rentals=new ArrayList<>(); systemUsers=new ArrayList<>();
        }
    }

    private static void saveData(){
        try{
            fileManager.saveVehicles(vehicles);
            fileManager.saveCustomers(customers);
            fileManager.saveRentals(rentals);
            System.out.println("Data saved successfully.");
        }catch(Exception e){
            System.err.println("Failed to save: "+e.getMessage());
        }
    }

    // ---------------- Admin Menu ----------------
    private static void adminMenu(Admin admin){
        while(true){
            System.out.println("\n--- Admin Menu ---");
            System.out.println("1. Add new vehicle");
            System.out.println("2. Register new customer");
            System.out.println("3. View all vehicles");
            System.out.println("4. View all customers");
            System.out.println("5. View all rentals");
            System.out.println("6. Search customer by ID");
            System.out.println("7. Search vehicle by ID");
            System.out.println("8. Create rental (Assign vehicle to customer)");
            System.out.println("9. Generate Reports");
            System.out.println("10. Save data");
            System.out.println("11. Logout");
            System.out.print("Choice: "); String c = scanner.nextLine();
            try{
                switch(c){
                    case "1": addVehicleFlow(); break;
                    case "2": registerFlow(); break;
                    case "3": vehicles.forEach(Vehicle::displayInfo); break;
                    case "4": customers.forEach(Customer::Display); break;
                    case "5": rentals.forEach(Rental::display); break;
                    case "6":
                        System.out.print("Customer ID: "); String cid=scanner.nextLine();
                        Customer cust = rentalService.findCustomerById(cid);
                        if(cust!=null) cust.Display(); else System.out.println("Not found");
                        break;
                    case "7":
                        System.out.print("Vehicle ID: "); String vid=scanner.nextLine();
                        Vehicle veh = rentalService.findVehicleById(vid);
                        if(veh!=null) veh.displayInfo(); else System.out.println("Not found");
                        break;
                    case "8": createRentalFlow(); break;
                    case "9": reportGenerator.generateAll(); break;
                    case "10": saveData(); break;
                    case "11": return;
                    default: System.out.println("Invalid choice");
                }
            }catch(Exception ex){ System.err.println("Error: "+ex.getMessage()); }
        }
    }

    private static void managerMenu(Manager manager){
        while(true){
            System.out.println("\n--- Manager Menu ---");
            System.out.println("1. View personal info");
            System.out.println("2. View all available vehicles");
            System.out.println("3. View all rental transactions");
            System.out.println("4. Process vehicle return");
            System.out.println("5. Update rental status / Cancel rental");
            System.out.println("6. View rental history");
            System.out.println("7. Generate Reports");
            System.out.println("8. Logout");
            System.out.print("Choice: "); String c = scanner.nextLine();
            try{
                switch(c){
                    case "1": manager.Display(); break;
                    case "2": rentalService.getAvailableVehicles().forEach(Vehicle::displayInfo); break;
                    case "3": rentals.forEach(Rental::display); break;
                    case "4":
                        System.out.print("Rental ID to return: "); String rid=scanner.nextLine();
                        System.out.print("Actual return date (YYYY-MM-DD) or empty for today: "); String d=scanner.nextLine();
                        LocalDate actual = d.isEmpty()? LocalDate.now() : LocalDate.parse(d);
                        rentalService.returnVehicle(rid, actual);
                        saveData();
                        break;
                    case "5":
                        System.out.print("Rental ID to cancel: "); String cr=scanner.nextLine();
                        rentalService.cancelRental(cr);
                        saveData();
                        break;
                    case "6": rentals.forEach(Rental::display); break;
                    case "7": reportGenerator.generateAll(); break;
                    case "8": return;
                }
            }catch(Exception ex){ System.err.println("Error: "+ex.getMessage()); }
        }
    }

    private static void customerMenu(Customer customer){
        while(true){
            System.out.println("\n--- Customer Menu ("+customer.getFullName()+") ---");
            System.out.println("1. View personal information");
            System.out.println("2. Browse available vehicles");
            System.out.println("3. View my rental history");
            System.out.println("4. Rent a vehicle");
            System.out.println("5. Return a vehicle");
            System.out.println("6. Cancel a rental booking");
            System.out.println("7. Logout");
            System.out.print("Choice: "); String c = scanner.nextLine();
            try{
                switch(c){
                    case "1": customer.Display(); break;
                    case "2": rentalService.getAvailableVehicles().forEach(Vehicle::displayInfo); break;
                    case "3": rentalService.getRentalsByCustomer(customer.getID()).forEach(Rental::display); break;
                    case "4": createRentalFlowForCustomer(customer); break;
                    case "5":
                        System.out.print("Rental ID to return: "); String rid=scanner.nextLine();
                        rentalService.returnVehicle(rid, LocalDate.now());
                        saveData();
                        break;
                    case "6":
                        System.out.print("Rental ID to cancel: "); String cid=scanner.nextLine();
                        rentalService.cancelRental(cid);
                        saveData();
                        break;
                    case "7": return;
                }
            }catch(Exception ex){ System.err.println("Error: "+ex.getMessage()); }
        }
    }

    private static void addVehicleFlow(){
        System.out.println("\nAdd Vehicle - Type: Car, Bike, Truck, SUV");
        System.out.print("Type: "); String type=scanner.nextLine();
        System.out.print("ID: "); String id=scanner.nextLine();
        System.out.print("Model: "); String model=scanner.nextLine();
        System.out.print("License Plate: "); String plate=scanner.nextLine();
        System.out.print("Year: "); int year=Integer.parseInt(scanner.nextLine());
        System.out.print("Price per day: "); double price=Double.parseDouble(scanner.nextLine());
        System.out.print("Status (Available/Rented/Maintenance): "); String status=scanner.nextLine();
        System.out.print("Fuel (Petrol/Diesel/Electric/Hybrid): "); String fuel=scanner.nextLine();
        System.out.print("Seating Capacity: "); int seats=Integer.parseInt(scanner.nextLine());

        Vehicle v=null;
        if("Car".equalsIgnoreCase(type)){
            System.out.print("Number of Doors: "); int doors=Integer.parseInt(scanner.nextLine());
            System.out.print("AC Yes/No: "); boolean ac="Yes".equalsIgnoreCase(scanner.nextLine());
            System.out.print("Transmission Automatic/Manual: "); String trans=scanner.nextLine();
            v = new Car(id, model, plate, year, price, status, fuel, seats, doors, ac, trans);
        } else if("Bike".equalsIgnoreCase(type)){
            System.out.print("Engine Capacity CC: "); int cc=Integer.parseInt(scanner.nextLine());
            System.out.print("Bike Type Sports/Cruiser/Standard: "); String btype=scanner.nextLine();
            v = new Bike(id, model, plate, year, price, status, fuel, seats, cc, btype);
        } else if("Truck".equalsIgnoreCase(type)){
            System.out.print("Cargo Capacity tons: "); double cargo=Double.parseDouble(scanner.nextLine());
            System.out.print("Number of Axles: "); int ax=Integer.parseInt(scanner.nextLine());
            v = new Truck(id, model, plate, year, price, status, fuel, seats, cargo, ax);
        } else if("SUV".equalsIgnoreCase(type)){
            System.out.print("Number of Doors: "); int doors=Integer.parseInt(scanner.nextLine());
            System.out.print("AC Yes/No: "); boolean ac="Yes".equalsIgnoreCase(scanner.nextLine());
            System.out.print("Transmission: "); String trans=scanner.nextLine();
            System.out.print("4WD Yes/No: "); boolean is4wd="Yes".equalsIgnoreCase(scanner.nextLine());
            System.out.print("Ground Clearance mm: "); int gc=Integer.parseInt(scanner.nextLine());
            v = new SUV(id, model, plate, year, price, status, fuel, seats, doors, ac, trans, is4wd, gc);
        } else {
            System.out.println("Unknown type");
            return;
        }
        rentalService.addVehicle(v);
        System.out.println("Vehicle added!");
    }

    private static void registerFlow(){
        try{
            System.out.print("Customer ID: "); String id=scanner.nextLine();
            System.out.print("Full Name: "); String name=scanner.nextLine();
            System.out.print("Username: "); String user=scanner.nextLine();
            System.out.print("Password: "); String pass=scanner.nextLine();
            System.out.print("Phone: "); String phone=scanner.nextLine();
            System.out.print("Email: "); String email=scanner.nextLine();
            System.out.print("Age: "); int age=Integer.parseInt(scanner.nextLine());
            System.out.print("Gender: "); String gender=scanner.nextLine();
            System.out.print("Driver License Number: "); String lic=scanner.nextLine();
            Customer c = authService.registerCustomer(id, name, user, pass, phone, email, age, gender, lic);
            System.out.println("Registered: "+c.getID());
        }catch(Exception ex){ System.err.println("Register failed: "+ex.getMessage()); }
    }

    private static void createRentalFlow(){
        System.out.print("Rental ID: "); String rid=scanner.nextLine();
        System.out.print("Customer ID: "); String cid=scanner.nextLine();
        System.out.print("Vehicle ID: "); String vid=scanner.nextLine();
        System.out.print("Rental Date YYYY-MM-DD: "); LocalDate rd=LocalDate.parse(scanner.nextLine());
        System.out.print("Return Date YYYY-MM-DD: "); LocalDate ret=LocalDate.parse(scanner.nextLine());
        Rental r = rentalService.createRental(rid, cid, vid, rd, ret);
        saveData();
    }

    private static void createRentalFlowForCustomer(Customer cust){
        System.out.print("Rental ID: "); String rid=scanner.nextLine();
        System.out.print("Vehicle ID: "); String vid=scanner.nextLine();
        System.out.print("Rental Date YYYY-MM-DD: "); LocalDate rd=LocalDate.parse(scanner.nextLine());
        System.out.print("Return Date YYYY-MM-DD: "); LocalDate ret=LocalDate.parse(scanner.nextLine());
        Rental r = rentalService.createRental(rid, cust.getID(), vid, rd, ret);
        saveData();
    }
}
