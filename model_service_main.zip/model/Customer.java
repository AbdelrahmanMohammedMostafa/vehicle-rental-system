package model;

public class Customer extends User {
    private int Age;
    private String Gender;
    private String LicenseNumber;
    
    public Customer(String ID, String FullName, String Username, String Password, String PhoneNumber, String Email_Address,int Age, String Gender, String LicenseNumber){
        super(ID, FullName,Username, Password, PhoneNumber, Email_Address);
       setAge(Age);
       this.Gender=Gender;
       setLicenseNumber(LicenseNumber);
    }
    public void setAge(int Age) {
        if(Age<18) throw new IllegalArgumentException("Customer should be at least 18 years old");
        this.Age=Age;
    }
    public void setGender(String Gender) { this.Gender = Gender; }
    public void setLicenseNumber(String LicenseNumber) {
        if(LicenseNumber==null || LicenseNumber.trim().isEmpty()){
             throw new IllegalArgumentException("Driving license is required!!");
        }
        this.LicenseNumber = LicenseNumber;
    }
    public int getAge() { return Age; }
    public String getGender() { return Gender; }
    public String getLicenseNumber() { return LicenseNumber; }
    @Override
    public void Display(){
        System.out.println("===========Customer Details==========");
        System.out.println("Name: "+getFullName());
        System.out.println("Customer ID: "+getID());
        System.out.println("Username: "+getUsername());
        System.out.println("Phone Number: "+getPhoneNumber());
        System.out.println("Email Address: "+getEmail_Address());
        System.out.println("Age: "+getAge());
        System.out.println("Gender: "+getGender());
        System.out.println("License Number: "+getLicenseNumber());
    }    
    public String toFileString(){
        return String.join(",", getID(), getFullName(), String.valueOf(Age), Gender, getPhoneNumber(), getEmail_Address(), LicenseNumber, getUsername(), getPassword());
    }
}
