package model;

public class Truck extends Vehicle {
    private double cargoCapacity;
    private int numberOfAxles;

    public Truck(String vehicleID, String model, String licensePlate, int year, double price, String status, String fuel, int seating,
                 double cargoCapacity, int numberOfAxles){
        super(vehicleID, model, "Truck", licensePlate, year, price, status, fuel, seating);
        this.cargoCapacity=cargoCapacity;
        this.numberOfAxles=numberOfAxles;
    }

    public double getCargoCapacity(){return cargoCapacity;}
    public int getNumberOfAxles(){return numberOfAxles;}

    @Override
    public String getVehicleTypeDetails(){
        return String.format("Cargo:%.1f tons, Axles:%d", cargoCapacity, numberOfAxles);
    }

    @Override
    public String toFileString(){
        return String.join(",", getVehicleID(), getModel(), getType(), getLicensePlate(), String.valueOf(getYear()),
                String.format("%.2f", getRentalPricePerDay()), getAvailabilityStatus(), getFuelType(), String.valueOf(getSeatingCapacity()),
                String.valueOf(cargoCapacity), String.valueOf(numberOfAxles));
    }
}
