package model;

public class SUV extends Car {
    private boolean is4WD;
    private int groundClearance;

    public SUV(String vehicleID, String model, String licensePlate, int year, double price, String status, String fuel, int seating,
               int numberOfDoors, boolean airConditioning, String transmission,
               boolean is4WD, int groundClearance){
        super(vehicleID, model, licensePlate, year, price, status, fuel, seating, numberOfDoors, airConditioning, transmission);
        // override type to SUV
        setType("SUV");
        this.is4WD=is4WD;
        this.groundClearance=groundClearance;
    }

    public boolean isIs4WD(){return is4WD;}
    public int getGroundClearance(){return groundClearance;}

    @Override
    public String getVehicleTypeDetails(){
        return super.getVehicleTypeDetails() + String.format(", 4WD:%s, Clearance:%dmm", is4WD?"Yes":"No", groundClearance);
    }

    @Override
    public String toFileString(){
        // V005,ToyotaFortuner,SUV,SUV789,2024,75.00,Available,Diesel,7,4,Yes,Automatic,Yes,220
        return String.join(",", getVehicleID(), getModel(), getType(), getLicensePlate(), String.valueOf(getYear()),
                String.format("%.2f", getRentalPricePerDay()), getAvailabilityStatus(), getFuelType(), String.valueOf(getSeatingCapacity()),
                String.valueOf(getNumberOfDoors()), isAirConditioning()?"Yes":"No", getTransmission(),
                is4WD?"Yes":"No", String.valueOf(groundClearance));
    }
}
