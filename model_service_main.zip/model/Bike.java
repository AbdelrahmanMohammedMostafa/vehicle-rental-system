package model;

public class Bike extends Vehicle {
    private int engineCapacity;
    private String bikeType; // Sports, Cruiser, Standard

    public Bike(String vehicleID, String model, String licensePlate, int year, double price, String status, String fuel, int seating,
                int engineCapacity, String bikeType){
        super(vehicleID, model, "Bike", licensePlate, year, price, status, fuel, seating);
        this.engineCapacity=engineCapacity;
        this.bikeType=bikeType;
    }

    public int getEngineCapacity(){return engineCapacity;}
    public String getBikeType(){return bikeType;}

    @Override
    public String getVehicleTypeDetails(){
        return String.format("CC:%d, Type:%s", engineCapacity, bikeType);
    }

    @Override
    public String toFileString(){
        return String.join(",", getVehicleID(), getModel(), getType(), getLicensePlate(), String.valueOf(getYear()),
                String.format("%.2f", getRentalPricePerDay()), getAvailabilityStatus(), getFuelType(), String.valueOf(getSeatingCapacity()),
                String.valueOf(engineCapacity), bikeType);
    }
}
