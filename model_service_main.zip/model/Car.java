package model;

public class Car extends Vehicle {
    private int numberOfDoors;
    private boolean airConditioning;
    private String transmission; // Automatic/Manual

    public Car(String vehicleID, String model, String licensePlate, int year, double price, String status, String fuel, int seating,
               int numberOfDoors, boolean airConditioning, String transmission){
        super(vehicleID, model, "Car", licensePlate, year, price, status, fuel, seating);
        this.numberOfDoors=numberOfDoors;
        this.airConditioning=airConditioning;
        this.transmission=transmission;
    }

    public int getNumberOfDoors(){return numberOfDoors;}
    public boolean isAirConditioning(){return airConditioning;}
    public String getTransmission(){return transmission;}

    public void setNumberOfDoors(int d){this.numberOfDoors=d;}
    public void setAirConditioning(boolean ac){this.airConditioning=ac;}
    public void setTransmission(String t){this.transmission=t;}

    @Override
    public String getVehicleTypeDetails(){
        return String.format("Doors:%d, AC:%s, Trans:%s", numberOfDoors, airConditioning?"Yes":"No", transmission);
    }

    @Override
    public String toFileString(){
        // V001,Toyota Camry,Car,ABC123,2023,50.00,Available,Petrol,5,4,No,Automatic
        return String.join(",", getVehicleID(), getModel(), getType(), getLicensePlate(), String.valueOf(getYear()),
                String.format("%.2f", getRentalPricePerDay()), getAvailabilityStatus(), getFuelType(), String.valueOf(getSeatingCapacity()),
                String.valueOf(numberOfDoors), airConditioning?"Yes":"No", transmission);
    }
}
