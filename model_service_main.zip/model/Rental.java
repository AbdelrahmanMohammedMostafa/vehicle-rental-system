package model;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Rental {
    private String RentalID;
    private String CustomerID;
    private String VehicleID;
    private LocalDate RentalDate;
    private LocalDate ReturnDate;
    private LocalDate ActualReturnDate;
    private double TotalCost;
    private String Status;
    
    public Rental(String RentalID, String CustomerID, String VehicleID, LocalDate RentalDate,LocalDate ReturnDate, LocalDate ActualReturnDate,double TotalCost, String Status){
        setRentalID(RentalID);
        setCustomerID(CustomerID);
        setVehicleID(VehicleID);
        setRentalDate(RentalDate);
        setReturnDate(ReturnDate);
        setActualReturnDate(ActualReturnDate);
        setTotalCost(TotalCost);
        setStatus(Status);
        validateDates();
    }

    private void validateDates(){
        if(RentalDate!=null && RentalDate.isBefore(LocalDate.now().minusDays(1))){
            // Allow past for loading history, but enforce on creation via service
        }
        if(RentalDate!=null && ReturnDate!=null && !ReturnDate.isAfter(RentalDate)){
            throw new IllegalArgumentException("Return date must be after rental date");
        }
        if("Cancelled".equalsIgnoreCase(Status) && "Completed".equalsIgnoreCase(Status)){
            throw new IllegalStateException("Cancelled rental cannot be marked as completed");
        }
    }

    public void setRentalID(String RentalID) {
        if(RentalID==null||RentalID.isEmpty()) throw new IllegalArgumentException("Rental ID required");
        this.RentalID = RentalID;
    }
    public void setCustomerID(String CustomerID) {
        if(CustomerID==null||CustomerID.isEmpty()) throw new IllegalArgumentException("Customer ID required");
        this.CustomerID = CustomerID;
    }
    public void setVehicleID(String VehicleID) {
        if(VehicleID==null||VehicleID.isEmpty()) throw new IllegalArgumentException("Vehicle ID required");
        this.VehicleID = VehicleID;
    }
    public void setRentalDate(LocalDate RentalDate) { this.RentalDate = RentalDate; }
    public void setReturnDate(LocalDate ReturnDate) { this.ReturnDate = ReturnDate; }
    public void setActualReturnDate(LocalDate ActualReturnDate) { this.ActualReturnDate = ActualReturnDate; }
    public void setTotalCost(double TotalCost) {
        if(TotalCost<0) throw new IllegalArgumentException("Cost cannot be negative");
        this.TotalCost = TotalCost;
    }
    public void setStatus(String Status) {
        if(Status==null) throw new IllegalArgumentException("Status required");
        if(this.Status!=null && "Cancelled".equalsIgnoreCase(this.Status) && "Completed".equalsIgnoreCase(Status)){
            throw new IllegalStateException("A cancelled rental cannot be marked as completed");
        }
        this.Status = Status;
    }

    public String getRentalID() { return RentalID; }
    public String getCustomerID() { return CustomerID; }
    public String getVehicleID() { return VehicleID; }
    public LocalDate getRentalDate() { return RentalDate; }
    public LocalDate getReturnDate() { return ReturnDate; }
    public LocalDate getActualReturnDate() { return ActualReturnDate; }
    public double getTotalCost() { return TotalCost; }
    public String getStatus() { return Status; }

    public long getDays(){
        if(RentalDate==null || ReturnDate==null) return 0;
        return ChronoUnit.DAYS.between(RentalDate, ReturnDate);
    }

    public String toFileString(){
        String actual = ActualReturnDate==null?"":ActualReturnDate.toString();
        return String.join(",", RentalID, CustomerID, VehicleID, 
            RentalDate!=null?RentalDate.toString():"",
            ReturnDate!=null?ReturnDate.toString():"",
            actual,
            String.format("%.2f", TotalCost), Status);
    }

    public void display(){
        System.out.printf("%s | Cust:%s | Veh:%s | %s -> %s | Actual:%s | %.2f | %s%n",
            RentalID, CustomerID, VehicleID, RentalDate, ReturnDate, 
            ActualReturnDate!=null?ActualReturnDate:"-", TotalCost, Status);
    }
}
