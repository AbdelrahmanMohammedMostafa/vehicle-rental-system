package model;

public abstract class User {
    private String ID;
    private String FullName;
    private String Username;
    private String Password;
    private String PhoneNumber;
    private String Email_Address;
    
    public User(){
    }
    
    public User(String ID, String FullName, String Username, String Password, String PhoneNumber, String Email_Address){
        setID(ID);
        setFullName(FullName);
        setUsername(Username);
        setPassword(Password);
        setPhoneNumber(PhoneNumber);
        setEmail_Address(Email_Address);
    }

    public void setID(String ID) {
        if(ID==null || ID.trim().isEmpty()) throw new IllegalArgumentException("ID cannot be empty");
        this.ID = ID;
    }
    public void setFullName(String FullName) {
        if(FullName==null || FullName.trim().isEmpty()) throw new IllegalArgumentException("Full Name cannot be empty");
        this.FullName = FullName;
    }
    public void setUsername(String Username) {
        if(Username==null || Username.trim().isEmpty()) throw new IllegalArgumentException("Username cannot be empty");
        this.Username = Username;
    }
    public void setPassword(String Password) {
        if(Password==null || Password.length()<4) throw new IllegalArgumentException("Password must be at least 4 chars");
        this.Password = Password;
    }
    public void setPhoneNumber(String PhoneNumber) {
        this.PhoneNumber = PhoneNumber;
    }
    public void setEmail_Address(String Email_Address) {
        if(Email_Address!=null && !Email_Address.contains("@")) throw new IllegalArgumentException("Invalid email");
        this.Email_Address = Email_Address;
    }

    public String getID() { return ID; }
    public String getFullName(){ return FullName; }
    public String getUsername() { return Username; }
    public String getPassword() { return Password; }
    public String getPhoneNumber() { return PhoneNumber; }
    public String getEmail_Address() { return Email_Address; }
    
    public abstract void Display();
}
