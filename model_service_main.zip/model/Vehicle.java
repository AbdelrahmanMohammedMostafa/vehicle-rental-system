package model;

public abstract class Vehicle {
    private String vehicleID;
    private String model;
    private String type; // Car, Bike, Truck, SUV
    private String licensePlate;
    private int year;
    private double rentalPricePerDay;
    private String availabilityStatus; // Available/Rented/Maintenance
    private String fuelType; // Petrol, Diesel, Electric, Hybrid
    private int seatingCapacity;

    public Vehicle(String vehicleID, String model, String type, String licensePlate, int year, double rentalPricePerDay, String availabilityStatus, String fuelType, int seatingCapacity){
        setVehicleID(vehicleID);
        setModel(model);
        setType(type);
        setLicensePlate(licensePlate);
        setYear(year);
        setRentalPricePerDay(rentalPricePerDay);
        setAvailabilityStatus(availabilityStatus);
        setFuelType(fuelType);
        setSeatingCapacity(seatingCapacity);
    }

    public void setVehicleID(String vehicleID){
        if(vehicleID==null||vehicleID.isEmpty()) throw new IllegalArgumentException("Vehicle ID required");
        this.vehicleID=vehicleID;
    }
    public void setModel(String model){ this.model=model; }
    public void setType(String type){ this.type=type; }
    public void setLicensePlate(String licensePlate){ this.licensePlate=licensePlate; }
    public void setYear(int year){
        if(year<1900 || year>2030) throw new IllegalArgumentException("Invalid year");
        this.year=year;
    }
    public void setRentalPricePerDay(double price){
        if(price<=0) throw new IllegalArgumentException("Price must be positive");
        this.rentalPricePerDay=price;
    }
    public void setAvailabilityStatus(String status){
        if(status==null) throw new IllegalArgumentException("Status required");
        this.availabilityStatus=status;
    }
    public void setFuelType(String fuelType){ this.fuelType=fuelType; }
    public void setSeatingCapacity(int cap){
        if(cap<=0) throw new IllegalArgumentException("Seating capacity must be >0");
        this.seatingCapacity=cap;
    }

    public String getVehicleID(){return vehicleID;}
    public String getModel(){return model;}
    public String getType(){return type;}
    public String getLicensePlate(){return licensePlate;}
    public int getYear(){return year;}
    public double getRentalPricePerDay(){return rentalPricePerDay;}
    public String getAvailabilityStatus(){return availabilityStatus;}
    public String getFuelType(){return fuelType;}
    public int getSeatingCapacity(){return seatingCapacity;}

    public boolean isAvailable(){ return "Available".equalsIgnoreCase(availabilityStatus); }

    public abstract String getVehicleTypeDetails();
    public abstract String toFileString();

    public void displayInfo(){
        System.out.printf("%s | %s | %s | Plate:%s | Year:%d | Price: %.2f/day | Status:%s | Fuel:%s | Seats:%d | %s%n",
            vehicleID, model, type, licensePlate, year, rentalPricePerDay, availabilityStatus, fuelType, seatingCapacity, getVehicleTypeDetails());
    }
}
