package model;

public class Admin extends User{
    public Admin(String ID, String FullName, String Username, String Password, String PhoneNumber, String Email_Address){
        super(ID,FullName,Username,Password,PhoneNumber,Email_Address);
    }
    @Override
     public void Display(){
        System.out.println("===========Admin Details==========");
        System.out.println("Name: "+getFullName());
        System.out.println("Admin ID: "+getID());
        System.out.println("Username: "+getUsername());
        System.out.println("Phone Number: "+getPhoneNumber());
        System.out.println("Email Address: "+getEmail_Address());        
    }
}
